# VOIDTUNE Optimizer Suite v0.8

## 🚀 Professional System Optimization Tool

**VOIDTUNE** is a powerful Windows optimization suite designed to enhance system performance, improve gaming experience, and streamline system management.

## 📥 Installation

**Recommended — MSI installer:** download `VOIDTUNE-0.8-Setup.msi` from the [Releases](https://github.com/otzpt/VOIDTUNE/releases) page and run it. Installs to `Program Files`, adds Start Menu + Desktop shortcuts, and registers in Add/Remove Programs (clean uninstall).

**Portable — ZIP:** download `VOIDTUNE_0.8V.zip`, extract anywhere, and run `VOIDTUNE.exe` (or `LAUNCH_VOIDTUNE.bat`). Requires Administrator privileges.

## 📁 Professional File Organization

```
VOIDTUNE_0.8/
├── core/                  # Core functionality modules
│   ├── hardware.ps1       # Hardware detection
│   ├── helpers.ps1        # Helper functions
│   ├── logging.ps1        # Logging system
│   └── models.ps1         # Data models
│
├── modules/               # Feature modules
│   ├── data.ps1           # Data management
│   ├── drivers.ps1        # Driver information
│   └── personalize.ps1    # Personalization
│
├── ui/                   # User interface
│   ├── events.ps1         # Event handlers
│   └── pages.ps1          # Page management
│
├── assets/               # Application assets
│   └── (icons, images)
│
├── config/               # Configuration files
│   └── settings.json
│
├── docs/                 # Documentation
│   └── CHANGELOG.md
│
├── backups/              # Backup files
├── logs/                 # Log files
│
├── VOIDTUNE.ps1          # Main application
├── VOIDTUNE.xaml          # Main UI (Professional)
├── VOIDTUNE_SPLASH.xaml   # Splash screen
├── LAUNCH_VOIDTUNE.bat    # Launcher
└── README.md             # This file
```

## 🎨 Professional UI Features

- **Modern Dark Theme**: Sleek #0E0E12 background with accent colors
- **CSS-like Color System**: Consistent brushes for easy theming
- **Professional Typography**: Segoe UI font family
- **Window Style**: Borderless with transparency support
- **Responsive Design**: Adapts to different screen sizes

## 🔧 Key Features

### Performance Optimization
- System performance tuning
- Memory management optimization
- Disk performance enhancements
- Network performance improvements

### System Cleanup
- Temporary file removal
- System log cleanup
- Disk cleanup utility

### Startup Management
- Startup delay optimization
- Unnecessary program cleanup
- Performance-focused startup

### One-Click Optimization
- Quick Actions panel
- Single button optimization
- Visual feedback system

## 📋 Version History

### v0.8 (Current)
- ✅ Professional file organization
- ✅ Modern UI with dark theme
- ✅ Enhanced performance optimizations
- ✅ Improved error handling
- ✅ One-click optimization button

### v0.7
- Initial public release
- Basic optimization features
- Standard UI design

## 🛠️ Development

### Requirements
- Windows 10/11
- PowerShell 5.1+
- Administrator privileges

### Building
1. Ensure all files are in the correct directories
2. Run `LAUNCH_VOIDTUNE.bat` as Administrator
3. Accept the disclaimer
4. Enjoy optimized performance!

## 📜 License

GNU General Public License v3.0

## 🤝 Contributing

Contributions are welcome! Please follow the professional code structure and maintain consistency with the existing design patterns.

## 📬 Contact

For support or questions, please refer to the official documentation or community forums.

---

**VOIDTUNE - Where Performance Meets Elegance** 🚀